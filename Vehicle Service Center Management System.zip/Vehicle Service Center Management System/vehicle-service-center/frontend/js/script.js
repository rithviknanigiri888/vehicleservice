// Shared frontend helpers
async function apiGet(path){ const res = await fetch(path); if(!res.ok) throw new Error(await res.text()); return res.json(); }
async function apiPost(path, data){ const res = await fetch(path,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams(data)}); if(!res.ok) throw new Error(await res.text()); return res.text(); }
// placeholder for shared functions if needed
