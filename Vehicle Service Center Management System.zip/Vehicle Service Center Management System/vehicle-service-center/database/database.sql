-- Database: vehicle_service_center
DROP DATABASE IF EXISTS vehicle_service_center;
CREATE DATABASE vehicle_service_center;
USE vehicle_service_center;

-- users (admin)
CREATE TABLE users (
  user_id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(100) NOT NULL UNIQUE,
  password VARCHAR(100) NOT NULL
);

-- customers
CREATE TABLE customers (
  customer_id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(200) NOT NULL,
  phone VARCHAR(50) NOT NULL,
  email VARCHAR(200),
  address VARCHAR(500)
);

-- vehicles
CREATE TABLE vehicles (
  vehicle_id INT AUTO_INCREMENT PRIMARY KEY,
  customer_id INT NOT NULL,
  vehicle_number VARCHAR(100) NOT NULL,
  brand VARCHAR(100),
  model VARCHAR(100),
  vehicle_type VARCHAR(100),
  manufacturing_year INT,
  FOREIGN KEY (customer_id) REFERENCES customers(customer_id) ON DELETE CASCADE
);

-- services
CREATE TABLE services (
  service_id INT AUTO_INCREMENT PRIMARY KEY,
  service_name VARCHAR(200) NOT NULL,
  description VARCHAR(500),
  price DECIMAL(10,2) NOT NULL
);

-- bookings
CREATE TABLE bookings (
  booking_id INT AUTO_INCREMENT PRIMARY KEY,
  customer_id INT NOT NULL,
  vehicle_id INT NOT NULL,
  service_id INT NOT NULL,
  booking_date DATE,
  problem_description VARCHAR(1000),
  status VARCHAR(50) DEFAULT 'Pending',
  remarks VARCHAR(1000),
  FOREIGN KEY (customer_id) REFERENCES customers(customer_id) ON DELETE CASCADE,
  FOREIGN KEY (vehicle_id) REFERENCES vehicles(vehicle_id) ON DELETE CASCADE,
  FOREIGN KEY (service_id) REFERENCES services(service_id) ON DELETE CASCADE
);

-- spare parts
CREATE TABLE spare_parts (
  part_id INT AUTO_INCREMENT PRIMARY KEY,
  part_name VARCHAR(200) NOT NULL,
  quantity INT DEFAULT 0,
  price DECIMAL(10,2) DEFAULT 0
);

-- bills
CREATE TABLE bills (
  bill_id INT AUTO_INCREMENT PRIMARY KEY,
  booking_id INT NOT NULL,
  service_charge DECIMAL(10,2) DEFAULT 0,
  parts_charge DECIMAL(10,2) DEFAULT 0,
  discount DECIMAL(10,2) DEFAULT 0,
  total_amount DECIMAL(10,2) DEFAULT 0,
  payment_status VARCHAR(50) DEFAULT 'Pending',
  bill_date DATE,
  FOREIGN KEY (booking_id) REFERENCES bookings(booking_id) ON DELETE CASCADE
);

-- sample data
INSERT INTO users(username,password) VALUES('admin','admin123');
INSERT INTO customers(name,phone,email,address) VALUES
('John Doe','555-0101','john@example.com','123 Main St'),
('Jane Smith','555-0202','jane@example.com','456 Oak Ave');

INSERT INTO vehicles(customer_id,vehicle_number,brand,model,vehicle_type,manufacturing_year) VALUES
(1,'ABC-123','Toyota','Corolla','Sedan',2015),
(2,'XYZ-789','Honda','Civic','Sedan',2018);

INSERT INTO services(service_name,description,price) VALUES
('Oil Change','Replace engine oil and filter',29.99),
('Brake Repair','Brake pads and rotor check/replace',199.99),
('Engine Tune','Engine tuning and diagnostics',149.99);

INSERT INTO spare_parts(part_name,quantity,price) VALUES
('Oil Filter',10,5.00),
('Brake Pad Set',5,45.00);

INSERT INTO bookings(customer_id,vehicle_id,service_id,booking_date,problem_description,status,remarks) VALUES
(1,1,1,CURDATE(),'Engine making noise','Pending',''),
(2,2,2,CURDATE(),'Brakes squeaking','Confirmed','');

INSERT INTO bills(booking_id,service_charge,parts_charge,discount,total_amount,payment_status,bill_date) VALUES
(1,29.99,5.00,0,34.99,'Pending',CURDATE());
