package com.vehicleservice.model;

public class Booking {
    private int booking_id;
    private int customer_id;
    private int vehicle_id;
    private int service_id;
    private String booking_date;
    private String problem_description;
    private String status;
    private String remarks;

    public Booking() {}
    public int getBooking_id(){return booking_id;} public void setBooking_id(int id){this.booking_id=id;}
    public int getCustomer_id(){return customer_id;} public void setCustomer_id(int id){this.customer_id=id;}
    public int getVehicle_id(){return vehicle_id;} public void setVehicle_id(int id){this.vehicle_id=id;}
    public int getService_id(){return service_id;} public void setService_id(int id){this.service_id=id;}
    public String getBooking_date(){return booking_date;} public void setBooking_date(String d){this.booking_date=d;}
    public String getProblem_description(){return problem_description;} public void setProblem_description(String s){this.problem_description=s;}
    public String getStatus(){return status;} public void setStatus(String s){this.status=s;}
    public String getRemarks(){return remarks;} public void setRemarks(String r){this.remarks=r;}
}
