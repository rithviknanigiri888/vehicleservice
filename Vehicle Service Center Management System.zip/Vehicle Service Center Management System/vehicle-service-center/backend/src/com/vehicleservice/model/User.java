package com.vehicleservice.model;

public class User {
    private int user_id;
    private String username;
    private String password;

    public User() {}
    public int getUser_id(){return user_id;} public void setUser_id(int id){this.user_id=id;}
    public String getUsername(){return username;} public void setUsername(String s){this.username=s;}
    public String getPassword(){return password;} public void setPassword(String s){this.password=s;}
}
