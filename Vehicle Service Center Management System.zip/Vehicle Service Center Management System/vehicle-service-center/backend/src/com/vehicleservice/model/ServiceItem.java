package com.vehicleservice.model;

public class ServiceItem {
    private int service_id;
    private String service_name;
    private String description;
    private double price;

    public ServiceItem() {}
    public int getService_id(){return service_id;} public void setService_id(int id){this.service_id=id;}
    public String getService_name(){return service_name;} public void setService_name(String s){this.service_name=s;}
    public String getDescription(){return description;} public void setDescription(String s){this.description=s;}
    public double getPrice(){return price;} public void setPrice(double p){this.price=p;}
}
