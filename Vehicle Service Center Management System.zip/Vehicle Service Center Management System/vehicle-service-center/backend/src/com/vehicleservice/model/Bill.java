package com.vehicleservice.model;

public class Bill {
    private int bill_id;
    private int booking_id;
    private double service_charge;
    private double parts_charge;
    private double discount;
    private double total_amount;
    private String payment_status;
    private String bill_date;

    public Bill() {}
    public int getBill_id(){return bill_id;} public void setBill_id(int id){this.bill_id=id;}
    public int getBooking_id(){return booking_id;} public void setBooking_id(int id){this.booking_id=id;}
    public double getService_charge(){return service_charge;} public void setService_charge(double d){this.service_charge=d;}
    public double getParts_charge(){return parts_charge;} public void setParts_charge(double d){this.parts_charge=d;}
    public double getDiscount(){return discount;} public void setDiscount(double d){this.discount=d;}
    public double getTotal_amount(){return total_amount;} public void setTotal_amount(double d){this.total_amount=d;}
    public String getPayment_status(){return payment_status;} public void setPayment_status(String s){this.payment_status=s;}
    public String getBill_date(){return bill_date;} public void setBill_date(String s){this.bill_date=s;}
}
