package com.vehicleservice.model;

public class Vehicle {
    private int vehicle_id;
    private int customer_id;
    private String vehicle_number;
    private String brand;
    private String model;
    private String vehicle_type;
    private int manufacturing_year;

    public Vehicle() {}
    // getters and setters
    public int getVehicle_id(){return vehicle_id;} public void setVehicle_id(int id){this.vehicle_id=id;}
    public int getCustomer_id(){return customer_id;} public void setCustomer_id(int id){this.customer_id=id;}
    public String getVehicle_number(){return vehicle_number;} public void setVehicle_number(String s){this.vehicle_number=s;}
    public String getBrand(){return brand;} public void setBrand(String s){this.brand=s;}
    public String getModel(){return model;} public void setModel(String s){this.model=s;}
    public String getVehicle_type(){return vehicle_type;} public void setVehicle_type(String s){this.vehicle_type=s;}
    public int getManufacturing_year(){return manufacturing_year;} public void setManufacturing_year(int y){this.manufacturing_year=y;}
}
