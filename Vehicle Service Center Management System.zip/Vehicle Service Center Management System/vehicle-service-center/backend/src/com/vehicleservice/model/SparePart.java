package com.vehicleservice.model;

public class SparePart {
    private int part_id;
    private String part_name;
    private int quantity;
    private double price;

    public SparePart() {}
    public int getPart_id(){return part_id;} public void setPart_id(int id){this.part_id=id;}
    public String getPart_name(){return part_name;} public void setPart_name(String s){this.part_name=s;}
    public int getQuantity(){return quantity;} public void setQuantity(int q){this.quantity=q;}
    public double getPrice(){return price;} public void setPrice(double p){this.price=p;}
}
