package com.vehicleservice.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {

    private static final String HOST = "localhost";
    private static final String PORT = "3306";
    private static final String DB = "vehicle_service_center";
    private static final String USER = "root";
    private static final String PASS = "MySql@12345";

    private static final String URL =
            "jdbc:mysql://" + HOST + ":" + PORT + "/" + DB
            + "?useSSL=false&serverTimezone=UTC";

    static {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            System.err.println("MySQL JDBC Driver not found.");
            e.printStackTrace();
        }
    }

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASS);
    }

    public static String getJdbcUrl() {
        return URL;
    }
}