package com.vehicleservice;

import com.sun.net.httpserver.HttpServer;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.vehicleservice.dao.*;
import com.vehicleservice.model.*;

import java.io.*;
import java.net.InetSocketAddress;
import java.net.URLDecoder;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) throws Exception{
        HttpServer server = HttpServer.create(new InetSocketAddress(8000),0);
        server.createContext("/", new StaticHandler());
        server.createContext("/api/login", new LoginHandler());
        server.createContext("/api/customers", new CustomersHandler());
        server.createContext("/api/vehicles", new VehiclesHandler());
        server.createContext("/api/services", new ServicesHandler());
        server.createContext("/api/bookings", new BookingsHandler());
        server.createContext("/api/bookings/status", new BookingStatusHandler());
        server.createContext("/api/parts", new PartsHandler());
        server.createContext("/api/bills", new BillsHandler());
        server.createContext("/api/dashboard", new DashboardHandler());
        server.setExecutor(null);
        System.out.println("Server running at http://localhost:8000/");
        server.start();
    }

    static Map<String,String> parseForm(InputStream is) throws IOException{
        String body = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"));
        Map<String,String> map = new HashMap<>();
        for(String pair: body.split("&")){ if(pair.isEmpty()) continue; String[] kv = pair.split("=",2); String k = URLDecoder.decode(kv[0],"UTF-8"); String v = kv.length>1?URLDecoder.decode(kv[1],"UTF-8"):""; map.put(k,v); }
        return map;
    }

    static void sendJson(HttpExchange ex, String json) throws IOException{ byte[] b=json.getBytes("UTF-8"); ex.getResponseHeaders().set("Content-Type","application/json; charset=utf-8"); ex.sendResponseHeaders(200,b.length); ex.getResponseBody().write(b); ex.close(); }
    static void sendText(HttpExchange ex, int code, String txt) throws IOException{ byte[] b=txt.getBytes("UTF-8"); ex.getResponseHeaders().set("Content-Type","text/plain; charset=utf-8"); ex.sendResponseHeaders(code,b.length); ex.getResponseBody().write(b); ex.close(); }

    static class StaticHandler implements HttpHandler{ public void handle(HttpExchange ex) throws IOException{ String path = ex.getRequestURI().getPath(); if(path.equals("/")) path="/frontend/index.html"; else path="/frontend"+path; File f = new File("."+path); if(!f.exists() || f.isDirectory()){ sendText(ex,404,"Not Found"); return; } byte[] bytes = Files.readAllBytes(Paths.get(f.getPath())); String ct = Files.probeContentType(f.toPath()); if(ct==null) ct="application/octet-stream"; ex.getResponseHeaders().set("Content-Type",ct); ex.sendResponseHeaders(200,bytes.length); ex.getResponseBody().write(bytes); ex.close(); } }

    static class LoginHandler implements HttpHandler{ public void handle(HttpExchange ex) throws IOException{ try{ if(!"POST".equalsIgnoreCase(ex.getRequestMethod())){ sendText(ex,405,"Method not allowed"); return; } Map<String,String> m = parseForm(ex.getRequestBody()); String user = m.get("username"); String pass = m.get("password"); if(user==null||pass==null){ sendText(ex,400,"Missing"); return; } try{ if(UserDAO.validate(user,pass)){ sendText(ex,200,"OK"); } else sendText(ex,401,"Invalid credentials"); } catch(SQLException e){ e.printStackTrace(); sendText(ex,500,"DB error"); } } finally{ ex.close(); } } }

    static class CustomersHandler implements HttpHandler{ public void handle(HttpExchange ex) throws IOException{ try{ String method = ex.getRequestMethod(); String qs = ex.getRequestURI().getQuery(); Map<String,String> qmap = queryToMap(qs);
            if("GET".equalsIgnoreCase(method)){
                try{ if(qmap.containsKey("customer_id")){ int id=Integer.parseInt(qmap.get("customer_id")); Customer c=CustomerDAO.getById(id); if(c==null){ sendText(ex,404,"Not found"); } else sendJson(ex,toJsonCustomer(c)); } else { String s=qmap.getOrDefault("search",null); List<Customer> list=CustomerDAO.getAll(s); sendJson(ex,toJsonCustomerList(list)); } } catch(SQLException e){ e.printStackTrace(); sendText(ex,500,"DB error"); }
            } else if("POST".equalsIgnoreCase(method)){
                Map<String,String> m = parseForm(ex.getRequestBody()); if(m.get("name")==null || m.get("phone")==null){ sendText(ex,400,"Missing fields"); return; }
                Customer c=new Customer(); c.setName(m.get("name")); c.setPhone(m.get("phone")); c.setEmail(m.getOrDefault("email","")); c.setAddress(m.getOrDefault("address","")); try{ if(CustomerDAO.add(c)) sendText(ex,200,"Created"); else sendText(ex,500,"Insert failed"); } catch(SQLException e){ e.printStackTrace(); sendText(ex,500,"DB error"); }
            } else if("PUT".equalsIgnoreCase(method)){
                Map<String,String> m=parseForm(ex.getRequestBody()); String cid = ex.getRequestURI().getQuery()!=null?queryToMap(ex.getRequestURI().getQuery()).get("customer_id"):null; if(cid==null){ sendText(ex,400,"Missing id"); return; } int id=Integer.parseInt(cid); Customer c=new Customer(); c.setCustomer_id(id); c.setName(m.getOrDefault("name","")); c.setPhone(m.getOrDefault("phone","")); c.setEmail(m.getOrDefault("email","")); c.setAddress(m.getOrDefault("address","")); try{ if(CustomerDAO.update(c)) sendText(ex,200,"Updated"); else sendText(ex,500,"Update failed"); } catch(SQLException e){ e.printStackTrace(); sendText(ex,500,"DB error"); }
            } else if("DELETE".equalsIgnoreCase(method)){
                String cid = ex.getRequestURI().getQuery()!=null?queryToMap(ex.getRequestURI().getQuery()).get("customer_id"):null; if(cid==null){ sendText(ex,400,"Missing id"); return; } int id=Integer.parseInt(cid); try{ if(CustomerDAO.delete(id)) sendText(ex,200,"Deleted"); else sendText(ex,500,"Delete failed"); } catch(SQLException e){ e.printStackTrace(); sendText(ex,500,"DB error"); }
            } else sendText(ex,405,"Method not allowed");
        } finally{ ex.close(); }
    }}

    static class VehiclesHandler implements HttpHandler{ public void handle(HttpExchange ex) throws IOException{ try{ String method = ex.getRequestMethod(); Map<String,String> qmap = queryToMap(ex.getRequestURI().getQuery()); if("GET".equalsIgnoreCase(method)){
                try{ if(qmap.containsKey("vehicle_id")){ int id=Integer.parseInt(qmap.get("vehicle_id")); Vehicle v=VehicleDAO.getById(id); if(v==null) sendText(ex,404,"Not found"); else sendJson(ex,toJsonVehicle(v)); } else { String s=qmap.getOrDefault("search",null); List<Vehicle> list=VehicleDAO.getAll(s); sendJson(ex,toJsonVehicleList(list)); } } catch(SQLException e){ e.printStackTrace(); sendText(ex,500,"DB error"); }
            } else if("POST".equalsIgnoreCase(method)){
                Map<String,String> m=parseForm(ex.getRequestBody()); Vehicle v=new Vehicle(); v.setCustomer_id(Integer.parseInt(m.get("customer_id"))); v.setVehicle_number(m.get("vehicle_number")); v.setBrand(m.getOrDefault("brand","")); v.setModel(m.getOrDefault("model","")); v.setVehicle_type(m.getOrDefault("vehicle_type","")); v.setManufacturing_year(Integer.parseInt(m.getOrDefault("manufacturing_year","0"))); try{ if(VehicleDAO.add(v)) sendText(ex,200,"Created"); else sendText(ex,500,"Insert failed"); } catch(SQLException e){ e.printStackTrace(); sendText(ex,500,"DB error"); }
            } else if("PUT".equalsIgnoreCase(method)){
                Map<String,String> m=parseForm(ex.getRequestBody()); String vid = queryToMap(ex.getRequestURI().getQuery()).get("vehicle_id"); if(vid==null){ sendText(ex,400,"Missing id"); return; } Vehicle v=new Vehicle(); v.setVehicle_id(Integer.parseInt(vid)); v.setCustomer_id(Integer.parseInt(m.getOrDefault("customer_id","0"))); v.setVehicle_number(m.getOrDefault("vehicle_number","")); v.setBrand(m.getOrDefault("brand","")); v.setModel(m.getOrDefault("model","")); v.setVehicle_type(m.getOrDefault("vehicle_type","")); v.setManufacturing_year(Integer.parseInt(m.getOrDefault("manufacturing_year","0"))); try{ if(VehicleDAO.update(v)) sendText(ex,200,"Updated"); else sendText(ex,500,"Update failed"); } catch(SQLException e){ e.printStackTrace(); sendText(ex,500,"DB error"); }
            } else if("DELETE".equalsIgnoreCase(method)){
                String vid=queryToMap(ex.getRequestURI().getQuery()).get("vehicle_id"); if(vid==null){ sendText(ex,400,"Missing id"); return; } try{ if(VehicleDAO.delete(Integer.parseInt(vid))) sendText(ex,200,"Deleted"); else sendText(ex,500,"Delete failed"); } catch(SQLException e){ e.printStackTrace(); sendText(ex,500,"DB error"); }
            } else sendText(ex,405,"Method not allowed"); } finally{ ex.close(); } } }

    static class ServicesHandler implements HttpHandler{ public void handle(HttpExchange ex) throws IOException{ try{ String method=ex.getRequestMethod(); Map<String,String> qmap=queryToMap(ex.getRequestURI().getQuery()); if("GET".equalsIgnoreCase(method)){ try{ if(qmap.containsKey("service_id")){ int id=Integer.parseInt(qmap.get("service_id")); ServiceItem s=ServiceDAO.getById(id); if(s==null) sendText(ex,404,"Not found"); else sendJson(ex,toJsonService(s)); } else { List<ServiceItem> list=ServiceDAO.getAll(); sendJson(ex,toJsonServiceList(list)); } } catch(SQLException e){ e.printStackTrace(); sendText(ex,500,"DB error"); } }
            else if("POST".equalsIgnoreCase(method)){ Map<String,String> m=parseForm(ex.getRequestBody()); ServiceItem s=new ServiceItem(); s.setService_name(m.getOrDefault("service_name","")); s.setDescription(m.getOrDefault("description","")); s.setPrice(Double.parseDouble(m.getOrDefault("price","0"))); try{ if(ServiceDAO.add(s)) sendText(ex,200,"Created"); else sendText(ex,500,"Insert failed"); } catch(SQLException e){ e.printStackTrace(); sendText(ex,500,"DB error"); } }
            else if("PUT".equalsIgnoreCase(method)){ Map<String,String> m=parseForm(ex.getRequestBody()); String sid=queryToMap(ex.getRequestURI().getQuery()).get("service_id"); if(sid==null){ sendText(ex,400,"Missing id"); return; } ServiceItem s=new ServiceItem(); s.setService_id(Integer.parseInt(sid)); s.setService_name(m.getOrDefault("service_name","")); s.setDescription(m.getOrDefault("description","")); s.setPrice(Double.parseDouble(m.getOrDefault("price","0"))); try{ if(ServiceDAO.update(s)) sendText(ex,200,"Updated"); else sendText(ex,500,"Update failed"); } catch(SQLException e){ e.printStackTrace(); sendText(ex,500,"DB error"); } }
            else if("DELETE".equalsIgnoreCase(method)){ String sid=queryToMap(ex.getRequestURI().getQuery()).get("service_id"); if(sid==null){ sendText(ex,400,"Missing id"); return; } try{ if(ServiceDAO.delete(Integer.parseInt(sid))) sendText(ex,200,"Deleted"); else sendText(ex,500,"Delete failed"); } catch(SQLException e){ e.printStackTrace(); sendText(ex,500,"DB error"); } }
            else sendText(ex,405,"Method not allowed"); } finally{ ex.close(); } } }

    static class BookingsHandler implements HttpHandler{ public void handle(HttpExchange ex) throws IOException{ try{ String method=ex.getRequestMethod(); Map<String,String> qmap=queryToMap(ex.getRequestURI().getQuery()); if("GET".equalsIgnoreCase(method)){ try{ if(qmap.containsKey("booking_id")){ int id=Integer.parseInt(qmap.get("booking_id")); Booking b=BookingDAO.getById(id); if(b==null) sendText(ex,404,"Not found"); else sendJson(ex,toJsonBooking(b)); } else { List<Booking> list=BookingDAO.getAll(); sendJson(ex,toJsonBookingList(list)); } } catch(SQLException e){ e.printStackTrace(); sendText(ex,500,"DB error"); } }
            else if("POST".equalsIgnoreCase(method)){ Map<String,String> m=parseForm(ex.getRequestBody()); Booking b=new Booking(); b.setCustomer_id(Integer.parseInt(m.getOrDefault("customer_id","0"))); b.setVehicle_id(Integer.parseInt(m.getOrDefault("vehicle_id","0"))); b.setService_id(Integer.parseInt(m.getOrDefault("service_id","0"))); b.setBooking_date(m.getOrDefault("booking_date", LocalDate.now().toString())); b.setProblem_description(m.getOrDefault("problem_description","")); b.setStatus(m.getOrDefault("status","Pending")); try{ if(BookingDAO.add(b)) sendText(ex,200,"Created"); else sendText(ex,500,"Insert failed"); } catch(SQLException e){ e.printStackTrace(); sendText(ex,500,"DB error"); } }
            else if("PUT".equalsIgnoreCase(method)){ Map<String,String> m=parseForm(ex.getRequestBody()); String bid=queryToMap(ex.getRequestURI().getQuery()).get("booking_id"); if(bid==null){ sendText(ex,400,"Missing id"); return; } Booking b=new Booking(); b.setBooking_id(Integer.parseInt(bid)); b.setCustomer_id(Integer.parseInt(m.getOrDefault("customer_id","0"))); b.setVehicle_id(Integer.parseInt(m.getOrDefault("vehicle_id","0"))); b.setService_id(Integer.parseInt(m.getOrDefault("service_id","0"))); b.setBooking_date(m.getOrDefault("booking_date",LocalDate.now().toString())); b.setProblem_description(m.getOrDefault("problem_description","")); b.setStatus(m.getOrDefault("status","Pending")); b.setRemarks(m.getOrDefault("remarks","")); try{ if(BookingDAO.update(b)) sendText(ex,200,"Updated"); else sendText(ex,500,"Update failed"); } catch(SQLException e){ e.printStackTrace(); sendText(ex,500,"DB error"); } }
            else if("DELETE".equalsIgnoreCase(method)){ String bid=queryToMap(ex.getRequestURI().getQuery()).get("booking_id"); if(bid==null){ sendText(ex,400,"Missing id"); return; } try{ if(BookingDAO.delete(Integer.parseInt(bid))) sendText(ex,200,"Deleted"); else sendText(ex,500,"Delete failed"); } catch(SQLException e){ e.printStackTrace(); sendText(ex,500,"DB error"); } }
            else sendText(ex,405,"Method not allowed"); } finally{ ex.close(); } } }

    static class BookingStatusHandler implements HttpHandler{ public void handle(HttpExchange ex) throws IOException{ try{ if(!"POST".equalsIgnoreCase(ex.getRequestMethod())){ sendText(ex,405,"Method not allowed"); return; } Map<String,String> m=parseForm(ex.getRequestBody()); int id=Integer.parseInt(m.getOrDefault("booking_id","0")); String status=m.getOrDefault("status",""); String remarks=m.getOrDefault("remarks",""); try{ if(BookingDAO.updateStatus(id,status,remarks)) sendText(ex,200,"Updated"); else sendText(ex,500,"Update failed"); } catch(SQLException e){ e.printStackTrace(); sendText(ex,500,"DB error"); } } finally{ ex.close(); } } }

    static class PartsHandler implements HttpHandler{ public void handle(HttpExchange ex) throws IOException{ try{ String method=ex.getRequestMethod(); Map<String,String> qmap=queryToMap(ex.getRequestURI().getQuery()); if("GET".equalsIgnoreCase(method)){ try{ List<com.vehicleservice.model.SparePart> list = SparePartDAO.getAll(); sendJson(ex,toJsonPartList(list)); } catch(SQLException e){ e.printStackTrace(); sendText(ex,500,"DB error"); } }
            else if("POST".equalsIgnoreCase(method)){ Map<String,String> m=parseForm(ex.getRequestBody()); com.vehicleservice.model.SparePart p=new com.vehicleservice.model.SparePart(); p.setPart_name(m.getOrDefault("part_name","")); p.setQuantity(Integer.parseInt(m.getOrDefault("quantity","0"))); p.setPrice(Double.parseDouble(m.getOrDefault("price","0"))); try{ if(SparePartDAO.add(p)) sendText(ex,200,"Created"); else sendText(ex,500,"Insert failed"); } catch(SQLException e){ e.printStackTrace(); sendText(ex,500,"DB error"); } }
            else if("PUT".equalsIgnoreCase(method)){ Map<String,String> m=parseForm(ex.getRequestBody()); String pid=qmap.get("part_id"); if(pid==null){ sendText(ex,400,"Missing id"); return; } com.vehicleservice.model.SparePart p=new com.vehicleservice.model.SparePart(); p.setPart_id(Integer.parseInt(pid)); p.setPart_name(m.getOrDefault("part_name","")); p.setQuantity(Integer.parseInt(m.getOrDefault("quantity","0"))); p.setPrice(Double.parseDouble(m.getOrDefault("price","0"))); try{ if(SparePartDAO.update(p)) sendText(ex,200,"Updated"); else sendText(ex,500,"Update failed"); } catch(SQLException e){ e.printStackTrace(); sendText(ex,500,"DB error"); } }
            else if("DELETE".equalsIgnoreCase(method)){ String pid=qmap.get("part_id"); if(pid==null){ sendText(ex,400,"Missing id"); return; } try{ if(SparePartDAO.delete(Integer.parseInt(pid))) sendText(ex,200,"Deleted"); else sendText(ex,500,"Delete failed"); } catch(SQLException e){ e.printStackTrace(); sendText(ex,500,"DB error"); } }
            else sendText(ex,405,"Method not allowed"); } finally{ ex.close(); } } }

    static class BillsHandler implements HttpHandler{ public void handle(HttpExchange ex) throws IOException{ try{ String method=ex.getRequestMethod(); Map<String,String> qmap=queryToMap(ex.getRequestURI().getQuery()); if("GET".equalsIgnoreCase(method)){ try{ List<com.vehicleservice.model.Bill> list=BillDAO.getAll(); sendJson(ex,toJsonBillList(list)); } catch(SQLException e){ e.printStackTrace(); sendText(ex,500,"DB error"); } }
            else if("POST".equalsIgnoreCase(method)){ Map<String,String> m=parseForm(ex.getRequestBody()); com.vehicleservice.model.Bill b=new com.vehicleservice.model.Bill(); b.setBooking_id(Integer.parseInt(m.getOrDefault("booking_id","0"))); b.setService_charge(Double.parseDouble(m.getOrDefault("service_charge","0"))); b.setParts_charge(Double.parseDouble(m.getOrDefault("parts_charge","0"))); b.setDiscount(Double.parseDouble(m.getOrDefault("discount","0"))); double total = b.getService_charge()+b.getParts_charge()-b.getDiscount(); b.setTotal_amount(total); b.setPayment_status(m.getOrDefault("payment_status","Pending")); b.setBill_date(LocalDate.now().toString()); try{ if(BillDAO.add(b)) sendText(ex,200,"Created"); else sendText(ex,500,"Insert failed"); } catch(SQLException e){ e.printStackTrace(); sendText(ex,500,"DB error"); } }
            else sendText(ex,405,"Method not allowed"); } finally{ ex.close(); } } }

    static class DashboardHandler implements HttpHandler{ public void handle(HttpExchange ex) throws IOException{ try{ Map<String,Object> out = new HashMap<>(); try{ List<com.vehicleservice.model.Customer> c = com.vehicleservice.dao.CustomerDAO.getAll(null); List<com.vehicleservice.model.Vehicle> v = com.vehicleservice.dao.VehicleDAO.getAll(null); List<com.vehicleservice.model.Booking> b = com.vehicleservice.dao.BookingDAO.getAll(); List<com.vehicleservice.model.Bill> bills = com.vehicleservice.dao.BillDAO.getAll(); double revenue = bills.stream().mapToDouble(x->x.getTotal_amount()).sum(); long pending = b.stream().filter(x->"Pending".equalsIgnoreCase(x.getStatus())).count(); out.put("customers", c.size()); out.put("vehicles", v.size()); out.put("pendingBookings", pending); out.put("revenue", revenue); List<Map<String,String>> recent = b.stream().limit(5).map(x->{ Map<String,String> m=new HashMap<>(); m.put("booking_id",String.valueOf(x.getBooking_id())); m.put("customer_name",String.valueOf(x.getCustomer_id())); m.put("vehicle_number",String.valueOf(x.getVehicle_id())); m.put("service_name",String.valueOf(x.getService_id())); m.put("booking_date",x.getBooking_date()); m.put("status",x.getStatus()); return m; }).collect(Collectors.toList()); out.put("recent", recent); sendJson(ex,toJson(out)); } catch(SQLException e){ e.printStackTrace(); sendText(ex,500,"DB error"); } } finally{ ex.close(); } } }

    // helpers
    static Map<String,String> queryToMap(String query){ Map<String,String> map=new HashMap<>(); if(query==null) return map; for(String pair:query.split("&")){ if(pair.isEmpty()) continue; String[] kv=pair.split("=",2); try{ String k=URLDecoder.decode(kv[0],"UTF-8"); String v=kv.length>1?URLDecoder.decode(kv[1],"UTF-8"):""; map.put(k,v); } catch(Exception e){ } } return map; }

    static String toJsonCustomer(Customer c){ return String.format("{\"customer_id\":%d,\"name\":\"%s\",\"phone\":\"%s\",\"email\":\"%s\",\"address\":\"%s\"}", c.getCustomer_id(), esc(c.getName()), esc(c.getPhone()), esc(c.getEmail()), esc(c.getAddress())); }
    static String toJsonCustomerList(List<Customer> list){ return "["+list.stream().map(Main::toJsonCustomer).collect(Collectors.joining(","))+"]"; }
    static String toJsonVehicle(Vehicle v){ return String.format("{\"vehicle_id\":%d,\"customer_id\":%d,\"vehicle_number\":\"%s\",\"brand\":\"%s\",\"model\":\"%s\",\"vehicle_type\":\"%s\",\"manufacturing_year\":%d}", v.getVehicle_id(), v.getCustomer_id(), esc(v.getVehicle_number()), esc(v.getBrand()), esc(v.getModel()), esc(v.getVehicle_type()), v.getManufacturing_year()); }
    static String toJsonVehicleList(List<Vehicle> list){ return "["+list.stream().map(Main::toJsonVehicle).collect(Collectors.joining(","))+"]"; }
    static String toJsonService(ServiceItem s){ return String.format("{\"service_id\":%d,\"service_name\":\"%s\",\"description\":\"%s\",\"price\":%s}", s.getService_id(), esc(s.getService_name()), esc(s.getDescription()), s.getPrice()); }
    static String toJsonServiceList(List<ServiceItem> list){ return "["+list.stream().map(Main::toJsonService).collect(Collectors.joining(","))+"]"; }
    static String toJsonBooking(Booking b){ return String.format("{\"booking_id\":%d,\"customer_id\":%d,\"vehicle_id\":%d,\"service_id\":%d,\"booking_date\":\"%s\",\"problem_description\":\"%s\",\"status\":\"%s\",\"remarks\":\"%s\"}", b.getBooking_id(), b.getCustomer_id(), b.getVehicle_id(), b.getService_id(), esc(b.getBooking_date()), esc(b.getProblem_description()), esc(b.getStatus()), esc(b.getRemarks())); }
    static String toJsonBookingList(List<Booking> list){ return "["+list.stream().map(Main::toJsonBooking).collect(Collectors.joining(","))+"]"; }
    static String toJsonPart(com.vehicleservice.model.SparePart p){ return String.format("{\"part_id\":%d,\"part_name\":\"%s\",\"quantity\":%d,\"price\":%s}", p.getPart_id(), esc(p.getPart_name()), p.getQuantity(), p.getPrice()); }
    static String toJsonPartList(List<com.vehicleservice.model.SparePart> list){ return "["+list.stream().map(Main::toJsonPart).collect(Collectors.joining(","))+"]"; }
    static String toJsonBill(com.vehicleservice.model.Bill b){ return String.format("{\"bill_id\":%d,\"booking_id\":%d,\"service_charge\":%s,\"parts_charge\":%s,\"discount\":%s,\"total_amount\":%s,\"payment_status\":\"%s\",\"bill_date\":\"%s\"}", b.getBill_id(), b.getBooking_id(), b.getService_charge(), b.getParts_charge(), b.getDiscount(), b.getTotal_amount(), esc(b.getPayment_status()), esc(b.getBill_date())); }
    static String toJsonBillList(List<com.vehicleservice.model.Bill> list){ return "["+list.stream().map(Main::toJsonBill).collect(Collectors.joining(","))+"]"; }
    static String toJson(Object obj){ // very small mapper for dashboard map
        if(obj instanceof Map){ Map<?,?> m=(Map<?,?>)obj; StringBuilder sb=new StringBuilder(); sb.append('{'); boolean first=true; for(Object k:m.keySet()){ if(!first) sb.append(','); first=false; sb.append('"').append(k.toString()).append('"').append(':'); Object v=m.get(k); if(v instanceof Number) sb.append(v.toString()); else if(v instanceof List) sb.append(toJsonList((List<?>)v)); else sb.append('"').append(esc(String.valueOf(v))).append('"'); } sb.append('}'); return sb.toString(); } return "{}"; }
    static String toJsonList(List<?> list){ StringBuilder sb=new StringBuilder(); sb.append('['); boolean first=true; for(Object o:list){ if(!first) sb.append(','); first=false; sb.append(toJson(o)); } sb.append(']'); return sb.toString(); }
    static String esc(Object o){ if(o==null) return ""; return o.toString().replace("\\","\\\\").replace("\"","\\\"").replace("\n","\\n"); }
}
