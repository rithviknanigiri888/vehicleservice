package com.vehicleservice.dao;

import com.vehicleservice.model.SparePart;
import com.vehicleservice.util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class SparePartDAO {
    public static List<SparePart> getAll() throws SQLException{ List<SparePart> list=new ArrayList<>(); String sql="SELECT * FROM spare_parts"; try(Connection con=DBConnection.getConnection(); PreparedStatement ps=con.prepareStatement(sql); ResultSet rs=ps.executeQuery()){ while(rs.next()){ SparePart p=new SparePart(); p.setPart_id(rs.getInt("part_id")); p.setPart_name(rs.getString("part_name")); p.setQuantity(rs.getInt("quantity")); p.setPrice(rs.getDouble("price")); list.add(p);} } return list; }
    public static SparePart getById(int id) throws SQLException{ String sql="SELECT * FROM spare_parts WHERE part_id=?"; try(Connection con=DBConnection.getConnection(); PreparedStatement ps=con.prepareStatement(sql)){ ps.setInt(1,id); try(ResultSet rs=ps.executeQuery()){ if(rs.next()){ SparePart p=new SparePart(); p.setPart_id(rs.getInt("part_id")); p.setPart_name(rs.getString("part_name")); p.setQuantity(rs.getInt("quantity")); p.setPrice(rs.getDouble("price")); return p; } } } return null; }
    public static boolean add(SparePart p) throws SQLException{ String sql="INSERT INTO spare_parts(part_name,quantity,price) VALUES(?,?,?)"; try(Connection con=DBConnection.getConnection(); PreparedStatement ps=con.prepareStatement(sql)){ ps.setString(1,p.getPart_name()); ps.setInt(2,p.getQuantity()); ps.setDouble(3,p.getPrice()); return ps.executeUpdate()>0; } }
    public static boolean update(SparePart p) throws SQLException{ String sql="UPDATE spare_parts SET part_name=?,quantity=?,price=? WHERE part_id=?"; try(Connection con=DBConnection.getConnection(); PreparedStatement ps=con.prepareStatement(sql)){ ps.setString(1,p.getPart_name()); ps.setInt(2,p.getQuantity()); ps.setDouble(3,p.getPrice()); ps.setInt(4,p.getPart_id()); return ps.executeUpdate()>0; } }
    public static boolean delete(int id) throws SQLException{ String sql="DELETE FROM spare_parts WHERE part_id=?"; try(Connection con=DBConnection.getConnection(); PreparedStatement ps=con.prepareStatement(sql)){ ps.setInt(1,id); return ps.executeUpdate()>0; } }
    public static boolean usePart(int part_id, int qty) throws SQLException{ String sql="UPDATE spare_parts SET quantity=quantity-? WHERE part_id=? AND quantity>=?"; try(Connection con=DBConnection.getConnection(); PreparedStatement ps=con.prepareStatement(sql)){ ps.setInt(1,qty); ps.setInt(2,part_id); ps.setInt(3,qty); return ps.executeUpdate()>0; } }
}
