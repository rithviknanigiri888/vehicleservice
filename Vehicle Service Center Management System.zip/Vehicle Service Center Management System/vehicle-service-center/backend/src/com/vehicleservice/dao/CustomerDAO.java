package com.vehicleservice.dao;

import com.vehicleservice.model.Customer;
import com.vehicleservice.util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CustomerDAO {
    public static List<Customer> getAll(String search) throws SQLException{
        List<Customer> list = new ArrayList<>();
        String sql = "SELECT * FROM customers" + (search!=null?" WHERE name LIKE ? OR phone LIKE ?":"");
        try(Connection con = DBConnection.getConnection(); PreparedStatement ps = con.prepareStatement(sql)){
            if(search!=null){ ps.setString(1, "%"+search+"%"); ps.setString(2, "%"+search+"%"); }
            try(ResultSet rs = ps.executeQuery()){
                while(rs.next()){ Customer c = new Customer(); c.setCustomer_id(rs.getInt("customer_id")); c.setName(rs.getString("name")); c.setPhone(rs.getString("phone")); c.setEmail(rs.getString("email")); c.setAddress(rs.getString("address")); list.add(c); }
            }
        }
        return list;
    }
    public static Customer getById(int id) throws SQLException{ String sql = "SELECT * FROM customers WHERE customer_id=?"; try(Connection con=DBConnection.getConnection(); PreparedStatement ps=con.prepareStatement(sql)){ ps.setInt(1,id); try(ResultSet rs=ps.executeQuery()){ if(rs.next()){ Customer c=new Customer(); c.setCustomer_id(rs.getInt("customer_id")); c.setName(rs.getString("name")); c.setPhone(rs.getString("phone")); c.setEmail(rs.getString("email")); c.setAddress(rs.getString("address")); return c; } } } return null; }
    public static boolean add(Customer c) throws SQLException{ String sql = "INSERT INTO customers(name,phone,email,address) VALUES(?,?,?,?)"; try(Connection con=DBConnection.getConnection(); PreparedStatement ps=con.prepareStatement(sql)){ ps.setString(1,c.getName()); ps.setString(2,c.getPhone()); ps.setString(3,c.getEmail()); ps.setString(4,c.getAddress()); return ps.executeUpdate()>0; } }
    public static boolean update(Customer c) throws SQLException{ String sql = "UPDATE customers SET name=?,phone=?,email=?,address=? WHERE customer_id=?"; try(Connection con=DBConnection.getConnection(); PreparedStatement ps=con.prepareStatement(sql)){ ps.setString(1,c.getName()); ps.setString(2,c.getPhone()); ps.setString(3,c.getEmail()); ps.setString(4,c.getAddress()); ps.setInt(5,c.getCustomer_id()); return ps.executeUpdate()>0; } }
    public static boolean delete(int id) throws SQLException{ String sql = "DELETE FROM customers WHERE customer_id=?"; try(Connection con=DBConnection.getConnection(); PreparedStatement ps=con.prepareStatement(sql)){ ps.setInt(1,id); return ps.executeUpdate()>0; } }
}
