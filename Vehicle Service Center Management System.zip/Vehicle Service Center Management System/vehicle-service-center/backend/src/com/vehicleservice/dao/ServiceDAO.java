package com.vehicleservice.dao;

import com.vehicleservice.model.ServiceItem;
import com.vehicleservice.util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ServiceDAO {
    public static List<ServiceItem> getAll() throws SQLException{ List<ServiceItem> list=new ArrayList<>(); String sql="SELECT * FROM services"; try(Connection con=DBConnection.getConnection(); PreparedStatement ps=con.prepareStatement(sql); ResultSet rs=ps.executeQuery()){ while(rs.next()){ ServiceItem s=new ServiceItem(); s.setService_id(rs.getInt("service_id")); s.setService_name(rs.getString("service_name")); s.setDescription(rs.getString("description")); s.setPrice(rs.getDouble("price")); list.add(s);} } return list; }
    public static ServiceItem getById(int id) throws SQLException{ String sql="SELECT * FROM services WHERE service_id=?"; try(Connection con=DBConnection.getConnection(); PreparedStatement ps=con.prepareStatement(sql)){ ps.setInt(1,id); try(ResultSet rs=ps.executeQuery()){ if(rs.next()){ ServiceItem s=new ServiceItem(); s.setService_id(rs.getInt("service_id")); s.setService_name(rs.getString("service_name")); s.setDescription(rs.getString("description")); s.setPrice(rs.getDouble("price")); return s; } } } return null; }
    public static boolean add(ServiceItem s) throws SQLException{ String sql="INSERT INTO services(service_name,description,price) VALUES(?,?,?)"; try(Connection con=DBConnection.getConnection(); PreparedStatement ps=con.prepareStatement(sql)){ ps.setString(1,s.getService_name()); ps.setString(2,s.getDescription()); ps.setDouble(3,s.getPrice()); return ps.executeUpdate()>0; } }
    public static boolean update(ServiceItem s) throws SQLException{ String sql="UPDATE services SET service_name=?,description=?,price=? WHERE service_id=?"; try(Connection con=DBConnection.getConnection(); PreparedStatement ps=con.prepareStatement(sql)){ ps.setString(1,s.getService_name()); ps.setString(2,s.getDescription()); ps.setDouble(3,s.getPrice()); ps.setInt(4,s.getService_id()); return ps.executeUpdate()>0; } }
    public static boolean delete(int id) throws SQLException{ String sql="DELETE FROM services WHERE service_id=?"; try(Connection con=DBConnection.getConnection(); PreparedStatement ps=con.prepareStatement(sql)){ ps.setInt(1,id); return ps.executeUpdate()>0; } }
}
