package com.vehicleservice.dao;

import com.vehicleservice.model.Bill;
import com.vehicleservice.util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class BillDAO {
    public static List<Bill> getAll() throws SQLException{ List<Bill> list=new ArrayList<>(); String sql="SELECT * FROM bills"; try(Connection con=DBConnection.getConnection(); PreparedStatement ps=con.prepareStatement(sql); ResultSet rs=ps.executeQuery()){ while(rs.next()){ Bill b=new Bill(); b.setBill_id(rs.getInt("bill_id")); b.setBooking_id(rs.getInt("booking_id")); b.setService_charge(rs.getDouble("service_charge")); b.setParts_charge(rs.getDouble("parts_charge")); b.setDiscount(rs.getDouble("discount")); b.setTotal_amount(rs.getDouble("total_amount")); b.setPayment_status(rs.getString("payment_status")); b.setBill_date(rs.getString("bill_date")); list.add(b);} } return list; }
    public static boolean add(Bill b) throws SQLException{ String sql="INSERT INTO bills(booking_id,service_charge,parts_charge,discount,total_amount,payment_status,bill_date) VALUES(?,?,?,?,?,?,?)"; try(Connection con=DBConnection.getConnection(); PreparedStatement ps=con.prepareStatement(sql)){ ps.setInt(1,b.getBooking_id()); ps.setDouble(2,b.getService_charge()); ps.setDouble(3,b.getParts_charge()); ps.setDouble(4,b.getDiscount()); ps.setDouble(5,b.getTotal_amount()); ps.setString(6,b.getPayment_status()); ps.setString(7,b.getBill_date()); return ps.executeUpdate()>0; } }
}
