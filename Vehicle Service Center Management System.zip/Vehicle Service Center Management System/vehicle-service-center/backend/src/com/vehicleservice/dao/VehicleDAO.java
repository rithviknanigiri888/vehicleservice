package com.vehicleservice.dao;

import com.vehicleservice.model.Vehicle;
import com.vehicleservice.util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class VehicleDAO {
    public static List<Vehicle> getAll(String search) throws SQLException{
        List<Vehicle> list = new ArrayList<>();
        String sql = "SELECT * FROM vehicles" + (search!=null?" WHERE vehicle_number LIKE ?":"");
        try(Connection con = DBConnection.getConnection(); PreparedStatement ps = con.prepareStatement(sql)){
            if(search!=null) ps.setString(1, "%"+search+"%");
            try(ResultSet rs = ps.executeQuery()){
                while(rs.next()){ Vehicle v = new Vehicle(); v.setVehicle_id(rs.getInt("vehicle_id")); v.setCustomer_id(rs.getInt("customer_id")); v.setVehicle_number(rs.getString("vehicle_number")); v.setBrand(rs.getString("brand")); v.setModel(rs.getString("model")); v.setVehicle_type(rs.getString("vehicle_type")); v.setManufacturing_year(rs.getInt("manufacturing_year")); list.add(v); }
            }
        }
        return list;
    }
    public static Vehicle getById(int id) throws SQLException{ String sql = "SELECT * FROM vehicles WHERE vehicle_id=?"; try(Connection con=DBConnection.getConnection(); PreparedStatement ps=con.prepareStatement(sql)){ ps.setInt(1,id); try(ResultSet rs=ps.executeQuery()){ if(rs.next()){ Vehicle v=new Vehicle(); v.setVehicle_id(rs.getInt("vehicle_id")); v.setCustomer_id(rs.getInt("customer_id")); v.setVehicle_number(rs.getString("vehicle_number")); v.setBrand(rs.getString("brand")); v.setModel(rs.getString("model")); v.setVehicle_type(rs.getString("vehicle_type")); v.setManufacturing_year(rs.getInt("manufacturing_year")); return v; } } } return null; }
    public static boolean add(Vehicle v) throws SQLException{ String sql = "INSERT INTO vehicles(customer_id,vehicle_number,brand,model,vehicle_type,manufacturing_year) VALUES(?,?,?,?,?,?)"; try(Connection con=DBConnection.getConnection(); PreparedStatement ps=con.prepareStatement(sql)){ ps.setInt(1,v.getCustomer_id()); ps.setString(2,v.getVehicle_number()); ps.setString(3,v.getBrand()); ps.setString(4,v.getModel()); ps.setString(5,v.getVehicle_type()); ps.setInt(6,v.getManufacturing_year()); return ps.executeUpdate()>0; } }
    public static boolean update(Vehicle v) throws SQLException{ String sql = "UPDATE vehicles SET customer_id=?,vehicle_number=?,brand=?,model=?,vehicle_type=?,manufacturing_year=? WHERE vehicle_id=?"; try(Connection con=DBConnection.getConnection(); PreparedStatement ps=con.prepareStatement(sql)){ ps.setInt(1,v.getCustomer_id()); ps.setString(2,v.getVehicle_number()); ps.setString(3,v.getBrand()); ps.setString(4,v.getModel()); ps.setString(5,v.getVehicle_type()); ps.setInt(6,v.getManufacturing_year()); ps.setInt(7,v.getVehicle_id()); return ps.executeUpdate()>0; } }
    public static boolean delete(int id) throws SQLException{ String sql = "DELETE FROM vehicles WHERE vehicle_id=?"; try(Connection con=DBConnection.getConnection(); PreparedStatement ps=con.prepareStatement(sql)){ ps.setInt(1,id); return ps.executeUpdate()>0; } }
}
