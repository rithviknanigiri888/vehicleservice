package com.vehicleservice.dao;

import com.vehicleservice.model.User;
import com.vehicleservice.util.DBConnection;

import java.sql.*;

public class UserDAO {
    public static boolean validate(String username, String password) throws SQLException{
        String sql = "SELECT * FROM users WHERE username=? AND password=?";
        try(Connection con=DBConnection.getConnection(); PreparedStatement ps=con.prepareStatement(sql)){ ps.setString(1,username); ps.setString(2,password); try(ResultSet rs=ps.executeQuery()){ return rs.next(); } }
    }
}
