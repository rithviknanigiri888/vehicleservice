# Vehicle Service Center Management System

Overview
- Simple full-stack project for managing a vehicle service center.
- Frontend: HTML/CSS/JS. Backend: Java (Core) using built-in HttpServer and JDBC. Database: MySQL.

Technologies
- Java 11+ (or later)
- MySQL 5.7+ / 8.0+
- VS Code (any IDE works)

Setup
1. Create the database:
   - Open MySQL client and run `database/database.sql` to create database and sample data.
2. Update DB credentials:
   - Edit `backend/src/com/vehicleservice/util/DBConnection.java` and set `USER` and `PASS`.
3. Add MySQL JDBC driver to classpath (mysql-connector-java). Place the jar in a `lib/` folder or use your build tool.

Compile and Run Backend (simple command line)
- From project root, compile:

```bash
javac -d out -cp "lib/*" backend/src/com/vehicleservice/util/DBConnection.java backend/src/com/vehicleservice/*.java backend/src/com/vehicleservice/model/*.java backend/src/com/vehicleservice/dao/*.java backend/src/com/vehicleservice/Main.java
```

- Run:

```bash
java -cp "out;lib/*" com.vehicleservice.Main
```

This starts a server at `http://localhost:8000/` serving the frontend and API endpoints.

Frontend
- Open `http://localhost:8000/` in your browser.
- Use `login.html` to login with default credentials (admin / admin123).

Default credentials
- Username: admin
- Password: admin123

How to test
- Use the admin interface (dashboard links) to manage customers, vehicles, services, bookings, spare parts, and billing.
- The backend exposes APIs under `/api/*` which the frontend uses via `fetch`.

Common issues
- JDBC driver not found: ensure `mysql-connector-java` is on the classpath when compiling and running.
- Database connection refused: check MySQL is running and credentials in `DBConnection.java` are correct.
- Port 8000 in use: modify the port in `Main.java`.

Notes
- This project is intentionally simple and uses core Java `HttpServer` to avoid external frameworks, making it easy to study and modify.
- For production, use proper password hashing, validation, and a robust web framework.
